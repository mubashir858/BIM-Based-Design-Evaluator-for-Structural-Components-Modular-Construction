package de4pb;

import java.awt.print.PrinterException;
import java.util.Collection;
import java.util.HashMap;
import java.util.TreeMap;
import javax.swing.JOptionPane;
import javax.swing.JTextPane;

/**
 *
 * @author hamid
 */
public final class Result extends javax.swing.JFrame {

    /**
     * Creates new form Result
     */
    
    String id, name, designation;
    TreeMap<String, Integer> record;
    int count;
    JTextPane pane = null;
    
    public Result(){
        initComponents();
    }
    
    public Result(String id, String name, String designation, HashMap<String, Integer> rec, int count) {
        initComponents();
        this.id = id;
        this.name = name;
        this.designation = designation;
        record = new TreeMap<>(rec);
        this.count = count;
        
        pane = new JTextPane();
        pane.setVisible(false);
        
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        
        int sc = calculateScore();
        String resString = getResultString(sc);
        resultString.setText(resString);
        score.setText(sc + "%");
        
        generateReport(sc, resString);
        
    }

    public int calculateScore(){
        double sum = 0;
        Collection<Integer> m = record.values();
        for(int n: m){
            sum += n;
        }
        return (int) Math.round((sum/count)*20);
    }
    
    public String getResultString(int sc){
        String resStr;
        if(sc <= 20){
            resStr = "Very Poor Compliance";
        }else if(sc <= 40){
            resStr = "Poor Compliance";
        }else if(sc <= 60){
            resStr = "Fair Compliance";
        }else if(sc <= 80){
            resStr = "Good Compliance";
        }else{
            resStr = "Excellent Compliance";
        }
        return resStr;
    }
    
    public void generateReport(int s, String resStr){
        String title;
        String reportString = "<html>";
        if(count == 63){
            title = "Design Evaluation by using Design for Manufacture and Assembly (DFMA)";
        }else{
            title = "Design Evaluation by using Lean Principles<br>(For Prefebricated Building Elements)";
        }
        reportString += "<p style='font-size: 20px; text-align: center'>"+title+"</p>";
        reportString += "<p style='font-size: 12px; text-align: center'>Evaluator: <span style='font-size:14px; font-weight:bold'>"+name+" | </span>Designation: <span style='font-size:14px; font-weight:bold'>"+designation+"</span></p>";
        reportString += "<p style='font-size: 12px; text-align: center'>Report Status: <span style='font-size: 16px'><b>"+resStr+"</b></span></p>";
        reportString += "<p style='font-size: 12px; text-align: center'>Evaluation Score: <b>"+s+"%</b></p>";
                
        
        String rstr = "<table style='width: 100%; >";
        
        int i=0, j=0, c=0;
        
        for (int x=0; x<count; x++){
            j++;
            if(i%3 == 0){
                j = 0;
                rstr += "<tr style='text-align: center'>";
            }
            String key;
            if(count == 63)
                key = "F"+(x+1)+"D";
            else{
                key = "F"+(x+1)+"L";
            }
            int value = record.get(key);            
            
            if(value > 2){
                rstr += "<td style='color: black; text-align: center'>"+key+"  :  "+value+"</td>";
            }else{
                rstr += "<td style='color: red; text-align: center'>"+key+"  :  "+value+"</td>";
                c ++;
            }
            
            ++i;
            
            if(j == 2){
                rstr += "</tr>\n";
            }
        }
        
        rstr += "</table>";
        
        reportString += "<p style='font-size: 12px; text-align: center'>Total non-compliance factors: <b>"+c+"</b></p>";
        
        reportString += "<p style='font-size: 14px; text-align: center'>Your Evaluation Input</p> <br>";
        reportString += rstr;
        reportString += "<br><p style='margin-left: 42px'>Note: Red marked factors need to imporove in design.</p>";
        pane.setContentType("text/html");
        pane.setText(reportString);
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        resultString = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        score = new javax.swing.JLabel();
        print = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(191, 191, 191));

        jLabel1.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel1.setText("DE4PB");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(245, 245, 245)
                .addComponent(jLabel1)
                .addContainerGap(247, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        resultString.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        resultString.setText("Very Poor Compliance");

        jLabel3.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel3.setText("Evaluation Score: ");

        score.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        score.setText("40%");

        print.setBackground(new java.awt.Color(215, 215, 215));
        print.setText("Print Report");
        print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(layout.createSequentialGroup()
                .addGap(213, 213, 213)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(score))
            .addGroup(layout.createSequentialGroup()
                .addGap(162, 162, 162)
                .addComponent(resultString))
            .addGroup(layout.createSequentialGroup()
                .addGap(235, 235, 235)
                .addComponent(print, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addComponent(resultString)
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(score))
                .addGap(47, 47, 47)
                .addComponent(print, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 125, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void printActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printActionPerformed
        try {
            pane.print();
        } catch (PrinterException ex) {
            JOptionPane.showMessageDialog(this, ex);
        }
    }//GEN-LAST:event_printActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Result.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Result.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Result.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Result.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Result().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton print;
    private javax.swing.JLabel resultString;
    private javax.swing.JLabel score;
    // End of variables declaration//GEN-END:variables
}
