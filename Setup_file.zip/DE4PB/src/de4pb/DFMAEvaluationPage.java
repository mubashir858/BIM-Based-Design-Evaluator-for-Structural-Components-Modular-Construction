package de4pb;

import java.awt.Color;
import java.awt.Image;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.SwingConstants;


/**
 *
 * @author hamid
 */
public final class DFMAEvaluationPage extends javax.swing.JFrame {

    String[] headings = new String[63];
    String[] description = new String[64];
    HashMap<String, Integer> record = new HashMap<>();
    HashMap<String, String> choosedOptions = new HashMap<>();
    JButton btns;
    String imagePath = "assets/dfma/D1.png";
    static int i = 0;
    Color gray = new Color(166, 166, 166);
    Color lightGray = new Color(230, 230, 230);
    
    String id, name, designation;
    
    public DFMAEvaluationPage(){
        initComponents();
    }
    
    public DFMAEvaluationPage(String id, String name, String designation) throws IOException{
        initComponents();
        this.id = id;
        this.name = name;
        this.designation = designation;
        headingsRead();
        descRead();
        desc.setLineWrap(true);
        allError.setVisible(false);
        desc.setText(description[0]);
        heading.setText(headings[0]);
        setImage();
        btns = f1d;
        btns.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));    
        initRecord();
        optionLabel.setHorizontalAlignment(SwingConstants.CENTER);
        submit.setEnabled(false);
//        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
    }
    
    public void headingsRead() throws FileNotFoundException, IOException{
        File hfile = new File("DFMA_Headings.txt");
        BufferedReader hbr = new BufferedReader(new FileReader(hfile));
        int count = 0;
        String st;
        while((st = hbr.readLine()) != null){
            headings[count++] = st;
        }        
    }
    
    public void descRead() throws FileNotFoundException, IOException {
        File file = new File("dfma.txt");
        BufferedReader br = new BufferedReader(new FileReader(file));
        String st;
        int count=0;
        while ( (st = br.readLine()) != null){
            if(count == 63){
                break;
            }
            String s = br.readLine();
            int buff = Integer.parseInt(s);
            String bigStr = "";
            for (int j=0; j<buff; j++){
                bigStr += br.readLine()+"\n";
            }
            description[count] = bigStr;
            count++;
        }
    }
    
    public void assignBtns(int pos){
        int a = pos;
        switch (a){
            case 1:
                btns = f1d;
                imagePath = "assets/dfma/D1.png";
                break;
            case 2:
                btns = f2d;
                imagePath = "assets/dfma/D2.png";
                break;
            case 3:
                btns = f3d;
                imagePath = "assets/dfma/D3.jpg";
                break;
            case 4:
                btns = f4d;
                imagePath = "assets/dfma/D4.jpg";
                break;
            case 5:
                btns = f5d;
                imagePath = "assets/dfma/D5.png";
                break;
            case 6:
                btns = f6d;
                imagePath = "assets/dfma/D6.jpg";
                break;
            case 7:
                btns = f7d;
                imagePath = "assets/dfma/D7.jpg";
                break;
            case 8:
                btns = f8d;
                imagePath = "assets/dfma/D8.png";
                break;
            case 9:
                btns = f9d;
                imagePath = "assets/dfma/D9.jpg";
                break;
            case 10:
                btns = f10d;
                imagePath = "assets/dfma/D10.jpg";
                break;
            case 11:
                btns = f11d;
                imagePath = "assets/dfma/D11.png";
                break;
            case 12:
                btns = f12d;
                imagePath = "assets/dfma/D12.jpg";
                break;
            case 13:
                btns = f13d;
                imagePath = "assets/dfma/D13.png";
                break;
            case 14:
                btns = f14d;
                imagePath = "assets/dfma/D14.jpg";
                break;
            case 15:
                btns = f15d;
                imagePath = "assets/dfma/D15.png";
                break;
            case 16:
                btns = f16d;
                imagePath = "assets/dfma/D16.png";
                break;
            case 17:
                btns = f17d;
                imagePath = "assets/dfma/D17.jpg";
                break;
            case 18:
                btns = f18d;
                imagePath = "assets/dfma/D18.jpg";
                break;
            case 19:
                btns = f19d;
                imagePath = "assets/dfma/D19.jpg";
                break;
            case 20:
                btns = f20d;
                imagePath = "assets/dfma/D20.jpg";
                break;
            case 21:
                btns = f21d;
                imagePath = "assets/dfma/D21.jpg";
                break;
            case 22:
                btns = f22d;
                imagePath = "assets/dfma/D22.jpg";
                break;
            case 23:
                btns = f23d;
                imagePath = "assets/dfma/D23.jpg";
                break;
            case 24:
                btns = f24d;
                imagePath = "assets/dfma/D24.png";
                break;
            case 25:
                btns = f25d;
                imagePath = "assets/dfma/D25.jpg";
                break;
            case 26:
                btns = f26d;
                imagePath = "assets/dfma/D26.jpg";
                break;
            case 27:
                btns = f27d;
                imagePath = "assets/dfma/D27.png";
                break;
            case 28:
                btns = f28d;
                imagePath = "assets/dfma/D28.jpg";
                break;
            case 29:
                btns = f29d;
                imagePath = "assets/dfma/D29.jpg";
                break;
            case 30:
                btns = f30d;
                imagePath = "assets/dfma/D30.jpg";
                break;
            case 31:
                btns = f31d;
                imagePath = "assets/dfma/D31.jpg";
                break;
            case 32:
                btns = f32d;
                imagePath = "assets/dfma/D32.png";
                break;
            case 33:
                btns = f33d;
                imagePath = "assets/dfma/D33.jpg";
                break;
            case 34:
                btns = f34d;
                imagePath = "assets/dfma/D34.png";
                break;
            case 35:
                btns = f35d;
                imagePath = "assets/dfma/D35.jpg";
                break;
            case 36:
                btns = f36d;
                imagePath = "assets/dfma/D36.png";
                break;
            case 37:
                btns = f37d;
                imagePath = "assets/dfma/D37.png";
                break;
            case 38:
                btns = f38d;
                imagePath = "assets/dfma/D38.png";
                break;
            case 39:
                btns = f39d;
                imagePath = "assets/dfma/D39.jpg";
                break;
            case 40:
                btns = f40d;
                imagePath = "assets/dfma/D40.png";
                break;    
            case 41:
                btns = f41d;
                imagePath = "assets/dfma/D41.jpg";
                break;    
            case 42:
                btns = f42d;
                imagePath = "assets/dfma/D42.png";
                break;    
            case 43:
                btns = f43d;
                imagePath = "assets/dfma/D43.png";
                break;    
            case 44:
                btns = f44d;
                imagePath = "assets/dfma/D44.jpg";
                break;    
            case 45:
                btns = f45d;
                imagePath = "assets/dfma/D45.png";
                break;    
            case 46:
                btns = f46d;
                imagePath = "assets/dfma/D46.png";
                break;    
            case 47:
                btns = f47d;
                imagePath = "assets/dfma/D47.jpg";
                break;    
            case 48:
                btns = f48d;
                imagePath = "assets/dfma/D48.png";
                break;    
            case 49:
                btns = f49d;
                imagePath = "assets/dfma/D49.png";
                break;    
            case 50:
                btns = f50d;
                imagePath = "assets/dfma/D50.png";
                break;
            case 51:
                btns = f51d;
                imagePath = "assets/dfma/D51.jpg";
                break;
            case 52:
                btns = f52d;
                imagePath = "assets/dfma/D52.jpg";
                break;
            case 53:
                btns = f53d;
                imagePath = "assets/dfma/D53.png";
                break;
            case 54:
                btns = f54d;
                imagePath = "assets/dfma/D54.jpg";
                break;
            case 55:
                btns = f55d;
                imagePath = "assets/dfma/D55.png";
                break;
            case 56:
                btns = f56d;
                imagePath = "assets/dfma/D56.jpg";
                break;
            case 57:
                btns = f57d;
                imagePath = "assets/dfma/D57.jpg";
                break;
            case 58:
                btns = f58d;
                imagePath = "assets/dfma/D58.jpg";
                break;
            case 59:
                btns = f59d;
                imagePath = "assets/dfma/D59.png";
                break;
            case 60:
                btns = f60d;
                imagePath = "assets/dfma/D60.jpg";
                break;
            case 61:
                btns = f61d;
                imagePath = "assets/dfma/D61.png";
                break;
            case 62:
                btns = f62d;
                imagePath = "assets/dfma/D62.jpg";
                break;
            case 63:
                btns = f63d;
                imagePath = "assets/dfma/D63.png";
                break;

        }
    }
    
    public boolean checkSelected(){
        boolean isSelected = false;
        if (radio1.isSelected()){
            isSelected = true;
        }
        else if (radio2.isSelected()){
            isSelected = true;
        }
        else if (radio3.isSelected()){
            isSelected = true;
        }
        else if (radio4.isSelected()){
            isSelected = true;
        }
        else if (radio5.isSelected()){
            isSelected = true;
        }
        return isSelected;
    }
   
    public int getSelected(){
        int res = 0;
        if (radio1.isSelected()){
            res = 1;
        }
        else if (radio2.isSelected()){
            res = 2;
        }
        else if (radio3.isSelected()){
            res = 3;
        }
        else if (radio4.isSelected()){
            res = 4;
        }
        else if (radio5.isSelected()){
            res = 5;
        }
        return res;
    }
    
    public String getSelectedString(){
        String res = "";
        if (radio1.isSelected()){
            res = "Very Unsatisfied";
        }
        else if (radio2.isSelected()){
            res = "Unsatisfied";
        }
        else if (radio3.isSelected()){
            res = "Neutral";
        }
        else if (radio4.isSelected()){
            res = "Satisfied";
        }
        else if (radio5.isSelected()){
            res = "Very Satisfied";
        }
        return res;
    }
    
    public void setSelectedBtn(){
        JRadioButton jrbtn = null;
        if(radio1.isSelected()){
            jrbtn = radio1;
        }else if(radio2.isSelected()){
            jrbtn = radio2;
        }else if(radio3.isSelected()){
            jrbtn = radio3;
        }else if(radio4.isSelected()){
            jrbtn = radio4;
        }else if(radio5.isSelected()){
            jrbtn = radio5;
        }
        
        jrbtn.setSelected(true);
    }
    
    public void setOption(){
        int opt = record.get("F"+i+"D");
        String txt = "";
        if(opt == 0){
            txt = "";
        }else if(opt == 1){
            txt = "Very Unsatisfied";
        }else if(opt == 2){
            txt = "Unsatisfied";
        }else if(opt == 3){
            txt = "Neutral";
        }else if(opt == 4){
            txt = "Satisfied";
        }else if(opt == 5){
            txt = "Very Satisfied";
        }
        optionLabel.setText(txt);
    }
    
    public ImageIcon image(String path){
        ImageIcon icon = new ImageIcon(path);
        Image image = icon.getImage(); // transform it 
        Image newimg = image.getScaledInstance(350, 200,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
        icon = new ImageIcon(newimg);
        return icon;
    }
    
    public void setImage() throws IOException{
        imgLabel.setIcon(image(imagePath));
        String path = "assets/dfma/";
        if(i==13)
            path += "D14_2.jpg";
        if(i==28)
            path += "D29_2.jpg";
        if(i==31)
            path += "D32_2.jpg";
        if(i==36)
            path += "D37_2.png";
        if(i==45)
            path += "D46_2.png";
        if(i==49)
            path += "D50_2.jpg";
        if(i==59)
            path += "D60_2.png";
        if(i==61)
            path += "D62_2.jpg"; 
        
        imgLabel2.setIcon(image(path));
    }

    public void initRecord(){
        record.put("F1D", 0);
        record.put("F2D", 0);
        record.put("F3D", 0);
        record.put("F4D", 0);
        record.put("F5D", 0);
        record.put("F6D", 0);
        record.put("F7D", 0);
        record.put("F8D", 0);
        record.put("F9D", 0);
        record.put("F10D", 0);
        record.put("F11D", 0);
        record.put("F12D", 0);
        record.put("F13D", 0);
        record.put("F14D", 0);
        record.put("F15D", 0);
        record.put("F16D", 0);
        record.put("F17D", 0);
        record.put("F18D", 0);
        record.put("F19D", 0);
        record.put("F20D", 0);
        record.put("F21D", 0);
        record.put("F22D", 0);
        record.put("F23D", 0);
        record.put("F24D", 0);
        record.put("F25D", 0);
        record.put("F26D", 0);
        record.put("F27D", 0);
        record.put("F28D", 0);
        record.put("F29D", 0);
        record.put("F30D", 0);
        record.put("F31D", 0);
        record.put("F32D", 0);
        record.put("F33D", 0);
        record.put("F34D", 0);
        record.put("F35D", 0);
        record.put("F36D", 0);
        record.put("F37D", 0);
        record.put("F38D", 0);
        record.put("F39D", 0);
        record.put("F40D", 0);
        record.put("F41D", 0);
        record.put("F42D", 0);
        record.put("F43D", 0);
        record.put("F44D", 0);
        record.put("F45D", 0);
        record.put("F46D", 0);
        record.put("F47D", 0);
        record.put("F48D", 0);
        record.put("F49D", 0);
        record.put("F50D", 0);
        record.put("F51D", 0);
        record.put("F52D", 0);
        record.put("F53D", 0);
        record.put("F54D", 0);
        record.put("F55D", 0);
        record.put("F56D", 0);
        record.put("F57D", 0);
        record.put("F58D", 0);
        record.put("F59D", 0);
        record.put("F60D", 0);
        record.put("F61D", 0);
        record.put("F62D", 0);
        record.put("F63D", 0);
    }
    
    public void initChoosedOptions(){
        choosedOptions.put("F1D", "");
        choosedOptions.put("F2D", "");
        choosedOptions.put("F3D", "");
        choosedOptions.put("F4D", "");
        choosedOptions.put("F5D", "");
        choosedOptions.put("F6D", "");
        choosedOptions.put("F7D", "");
        choosedOptions.put("F8D", "");
        choosedOptions.put("F9D", "");
        choosedOptions.put("F10D", "");
        choosedOptions.put("F11D", "");
        choosedOptions.put("F12D", "");
        choosedOptions.put("F13D", "");
        choosedOptions.put("F14D", "");
        choosedOptions.put("F15D", "");
        choosedOptions.put("F16D", "");
        choosedOptions.put("F17D", "");
        choosedOptions.put("F18D", "");
        choosedOptions.put("F19D", "");
        choosedOptions.put("F20D", "");
        choosedOptions.put("F21D", "");
        choosedOptions.put("F22D", "");
        choosedOptions.put("F23D", "");
        choosedOptions.put("F24D", "");
        choosedOptions.put("F25D", "");
        choosedOptions.put("F26D", "");
        choosedOptions.put("F27D", "");
        choosedOptions.put("F28D", "");
        choosedOptions.put("F29D", "");
        choosedOptions.put("F30D", "");
        choosedOptions.put("F31D", "");
        choosedOptions.put("F32D", "");
        choosedOptions.put("F33D", "");
        choosedOptions.put("F34D", "");
        choosedOptions.put("F35D", "");
        choosedOptions.put("F36D", "");
        choosedOptions.put("F37D", "");
        choosedOptions.put("F38D", "");
        choosedOptions.put("F39D", "");
        choosedOptions.put("F40D", "");
        choosedOptions.put("F41D", "");
        choosedOptions.put("F42D", "");
        choosedOptions.put("F43D", "");
        choosedOptions.put("F44D", "");
        choosedOptions.put("F45D", "");
        choosedOptions.put("F46D", "");
        choosedOptions.put("F47D", "");
        choosedOptions.put("F48D", "");
        choosedOptions.put("F49D", "");
        choosedOptions.put("F50D", "");
        choosedOptions.put("F51D", "");
        choosedOptions.put("F52D", "");
        choosedOptions.put("F53D", "");
        choosedOptions.put("F54D", "");
        choosedOptions.put("F55D", "");
        choosedOptions.put("F56D", "");
        choosedOptions.put("F57D", "");
        choosedOptions.put("F58D", "");
        choosedOptions.put("F59D", "");
        choosedOptions.put("F60D", "");
        choosedOptions.put("F61D", "");
        choosedOptions.put("F62D", "");
        choosedOptions.put("F63D", "");
    }
    
    public void checkAll(){
        if(record.containsValue(0)){
            submit.setEnabled(false);
        }else{
            submit.setEnabled(true);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        radioGroup = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        heading = new javax.swing.JLabel();
        imagePanel = new javax.swing.JPanel();
        imgLabel = new javax.swing.JLabel();
        imgLabel2 = new javax.swing.JLabel();
        radio1 = new javax.swing.JRadioButton();
        radio2 = new javax.swing.JRadioButton();
        radio3 = new javax.swing.JRadioButton();
        radio4 = new javax.swing.JRadioButton();
        radio5 = new javax.swing.JRadioButton();
        back = new javax.swing.JButton();
        next = new javax.swing.JButton();
        f1d = new javax.swing.JButton();
        f2d = new javax.swing.JButton();
        f3d = new javax.swing.JButton();
        f4d = new javax.swing.JButton();
        f5d = new javax.swing.JButton();
        f6d = new javax.swing.JButton();
        f7d = new javax.swing.JButton();
        f8d = new javax.swing.JButton();
        f9d = new javax.swing.JButton();
        f10d = new javax.swing.JButton();
        f17d = new javax.swing.JButton();
        f18d = new javax.swing.JButton();
        f19d = new javax.swing.JButton();
        f20d = new javax.swing.JButton();
        f11d = new javax.swing.JButton();
        f12d = new javax.swing.JButton();
        f13d = new javax.swing.JButton();
        f14d = new javax.swing.JButton();
        f15d = new javax.swing.JButton();
        f16d = new javax.swing.JButton();
        f27d = new javax.swing.JButton();
        f28d = new javax.swing.JButton();
        f29d = new javax.swing.JButton();
        f30d = new javax.swing.JButton();
        f37d = new javax.swing.JButton();
        f38d = new javax.swing.JButton();
        f39d = new javax.swing.JButton();
        f40d = new javax.swing.JButton();
        f31d = new javax.swing.JButton();
        f32d = new javax.swing.JButton();
        f33d = new javax.swing.JButton();
        f34d = new javax.swing.JButton();
        f35d = new javax.swing.JButton();
        f36d = new javax.swing.JButton();
        f21d = new javax.swing.JButton();
        f22d = new javax.swing.JButton();
        f23d = new javax.swing.JButton();
        f24d = new javax.swing.JButton();
        f25d = new javax.swing.JButton();
        f26d = new javax.swing.JButton();
        f61d = new javax.swing.JButton();
        f62d = new javax.swing.JButton();
        f63d = new javax.swing.JButton();
        f41d = new javax.swing.JButton();
        f42d = new javax.swing.JButton();
        f43d = new javax.swing.JButton();
        f44d = new javax.swing.JButton();
        f45d = new javax.swing.JButton();
        f46d = new javax.swing.JButton();
        f47d = new javax.swing.JButton();
        f48d = new javax.swing.JButton();
        f49d = new javax.swing.JButton();
        f50d = new javax.swing.JButton();
        f57d = new javax.swing.JButton();
        f58d = new javax.swing.JButton();
        f59d = new javax.swing.JButton();
        f60d = new javax.swing.JButton();
        f51d = new javax.swing.JButton();
        f52d = new javax.swing.JButton();
        f53d = new javax.swing.JButton();
        f54d = new javax.swing.JButton();
        f55d = new javax.swing.JButton();
        f56d = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        desc = new javax.swing.JTextArea();
        allError = new javax.swing.JLabel();
        optionLabel = new javax.swing.JLabel();
        submit = new javax.swing.JButton();
        submit1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(191, 191, 191));

        jLabel1.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel1.setText("Design Evaluation using DFMA ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(694, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(473, 473, 473))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        heading.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        heading.setText("heading");

        javax.swing.GroupLayout imagePanelLayout = new javax.swing.GroupLayout(imagePanel);
        imagePanel.setLayout(imagePanelLayout);
        imagePanelLayout.setHorizontalGroup(
            imagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(imagePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(imgLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 498, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(imgLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 444, Short.MAX_VALUE)
                .addContainerGap())
        );
        imagePanelLayout.setVerticalGroup(
            imagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, imagePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(imagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(imgLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(imgLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 234, Short.MAX_VALUE))
                .addContainerGap())
        );

        radioGroup.add(radio1);
        radio1.setText("Very Unsatisfied");

        radioGroup.add(radio2);
        radio2.setText("Usatisfied");

        radioGroup.add(radio3);
        radio3.setText("Neutral");
        radio3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radio3ActionPerformed(evt);
            }
        });

        radioGroup.add(radio4);
        radio4.setText("Satisfied");

        radioGroup.add(radio5);
        radio5.setText("Very Satisfied");

        back.setBackground(new java.awt.Color(215, 215, 215));
        back.setText("Back");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });

        next.setBackground(new java.awt.Color(215, 215, 215));
        next.setText("Next");
        next.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextActionPerformed(evt);
            }
        });

        f1d.setBackground(new java.awt.Color(230, 230, 230));
        f1d.setText("F1d");
        f1d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f2d.setBackground(new java.awt.Color(230, 230, 230));
        f2d.setText("F2d");
        f2d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f3d.setBackground(new java.awt.Color(230, 230, 230));
        f3d.setText("F3d");
        f3d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f4d.setBackground(new java.awt.Color(230, 230, 230));
        f4d.setText("F4d");
        f4d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f5d.setBackground(new java.awt.Color(230, 230, 230));
        f5d.setText("F5d");
        f5d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f6d.setBackground(new java.awt.Color(230, 230, 230));
        f6d.setText("F6d");
        f6d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f7d.setBackground(new java.awt.Color(230, 230, 230));
        f7d.setText("F7d");
        f7d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f8d.setBackground(new java.awt.Color(230, 230, 230));
        f8d.setText("F8d");
        f8d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f9d.setBackground(new java.awt.Color(230, 230, 230));
        f9d.setText("F9d");
        f9d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f10d.setBackground(new java.awt.Color(230, 230, 230));
        f10d.setText("F10d");
        f10d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f17d.setBackground(new java.awt.Color(230, 230, 230));
        f17d.setText("F17d");
        f17d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f18d.setBackground(new java.awt.Color(230, 230, 230));
        f18d.setText("F18d");
        f18d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f19d.setBackground(new java.awt.Color(230, 230, 230));
        f19d.setText("F19d");
        f19d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f20d.setBackground(new java.awt.Color(230, 230, 230));
        f20d.setText("F20d");
        f20d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f11d.setBackground(new java.awt.Color(230, 230, 230));
        f11d.setText("F11d");
        f11d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f12d.setBackground(new java.awt.Color(230, 230, 230));
        f12d.setText("F12d");
        f12d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f13d.setBackground(new java.awt.Color(230, 230, 230));
        f13d.setText("F13d");
        f13d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f14d.setBackground(new java.awt.Color(230, 230, 230));
        f14d.setText("F14d");
        f14d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f15d.setBackground(new java.awt.Color(230, 230, 230));
        f15d.setText("F15d");
        f15d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f16d.setBackground(new java.awt.Color(230, 230, 230));
        f16d.setText("F16d");
        f16d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f27d.setBackground(new java.awt.Color(230, 230, 230));
        f27d.setText("F27d");
        f27d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f28d.setBackground(new java.awt.Color(230, 230, 230));
        f28d.setText("F28d");
        f28d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f29d.setBackground(new java.awt.Color(230, 230, 230));
        f29d.setText("F29d");
        f29d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f30d.setBackground(new java.awt.Color(230, 230, 230));
        f30d.setText("F30d");
        f30d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f37d.setBackground(new java.awt.Color(230, 230, 230));
        f37d.setText("F37d");
        f37d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f38d.setBackground(new java.awt.Color(230, 230, 230));
        f38d.setText("F38d");
        f38d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f39d.setBackground(new java.awt.Color(230, 230, 230));
        f39d.setText("F39d");
        f39d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f40d.setBackground(new java.awt.Color(230, 230, 230));
        f40d.setText("F40d");
        f40d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f31d.setBackground(new java.awt.Color(230, 230, 230));
        f31d.setText("F31d");
        f31d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f32d.setBackground(new java.awt.Color(230, 230, 230));
        f32d.setText("F32d");
        f32d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f33d.setBackground(new java.awt.Color(230, 230, 230));
        f33d.setText("F33d");
        f33d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f34d.setBackground(new java.awt.Color(230, 230, 230));
        f34d.setText("F34d");
        f34d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f35d.setBackground(new java.awt.Color(230, 230, 230));
        f35d.setText("F35d");
        f35d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f36d.setBackground(new java.awt.Color(230, 230, 230));
        f36d.setText("F36d");
        f36d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f21d.setBackground(new java.awt.Color(230, 230, 230));
        f21d.setText("F21d");
        f21d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f22d.setBackground(new java.awt.Color(230, 230, 230));
        f22d.setText("F22d");
        f22d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f23d.setBackground(new java.awt.Color(230, 230, 230));
        f23d.setText("F23d");
        f23d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f24d.setBackground(new java.awt.Color(230, 230, 230));
        f24d.setText("F24d");
        f24d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f25d.setBackground(new java.awt.Color(230, 230, 230));
        f25d.setText("F25d");
        f25d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f26d.setBackground(new java.awt.Color(230, 230, 230));
        f26d.setText("F26d");
        f26d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f61d.setBackground(new java.awt.Color(230, 230, 230));
        f61d.setText("F61d");
        f61d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f62d.setBackground(new java.awt.Color(230, 230, 230));
        f62d.setText("F62d");
        f62d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f63d.setBackground(new java.awt.Color(230, 230, 230));
        f63d.setText("F63d");
        f63d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f41d.setBackground(new java.awt.Color(230, 230, 230));
        f41d.setText("F41d");
        f41d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f42d.setBackground(new java.awt.Color(230, 230, 230));
        f42d.setText("F42d");
        f42d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f43d.setBackground(new java.awt.Color(230, 230, 230));
        f43d.setText("F43d");
        f43d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f44d.setBackground(new java.awt.Color(230, 230, 230));
        f44d.setText("F44d");
        f44d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f45d.setBackground(new java.awt.Color(230, 230, 230));
        f45d.setText("F45d");
        f45d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f46d.setBackground(new java.awt.Color(230, 230, 230));
        f46d.setText("F46d");
        f46d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f47d.setBackground(new java.awt.Color(230, 230, 230));
        f47d.setText("F47d");
        f47d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f48d.setBackground(new java.awt.Color(230, 230, 230));
        f48d.setText("F48d");
        f48d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f49d.setBackground(new java.awt.Color(230, 230, 230));
        f49d.setText("F49d");
        f49d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f50d.setBackground(new java.awt.Color(230, 230, 230));
        f50d.setText("F50d");
        f50d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f57d.setBackground(new java.awt.Color(230, 230, 230));
        f57d.setText("F57d");
        f57d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f58d.setBackground(new java.awt.Color(230, 230, 230));
        f58d.setText("F58d");
        f58d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f59d.setBackground(new java.awt.Color(230, 230, 230));
        f59d.setText("F59d");
        f59d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f60d.setBackground(new java.awt.Color(230, 230, 230));
        f60d.setText("F60d");
        f60d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f51d.setBackground(new java.awt.Color(230, 230, 230));
        f51d.setText("F51d");
        f51d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f52d.setBackground(new java.awt.Color(230, 230, 230));
        f52d.setText("F52d");
        f52d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f53d.setBackground(new java.awt.Color(230, 230, 230));
        f53d.setText("F53d");
        f53d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f54d.setBackground(new java.awt.Color(230, 230, 230));
        f54d.setText("F54d");
        f54d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f55d.setBackground(new java.awt.Color(230, 230, 230));
        f55d.setText("F55d");
        f55d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f56d.setBackground(new java.awt.Color(230, 230, 230));
        f56d.setText("F56d");
        f56d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        jScrollPane1.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        desc.setEditable(false);
        desc.setBackground(new java.awt.Color(240, 240, 240));
        desc.setColumns(20);
        desc.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        desc.setRows(5);
        jScrollPane1.setViewportView(desc);

        allError.setForeground(new java.awt.Color(255, 0, 0));
        allError.setText("All questions must be answered!");

        optionLabel.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        optionLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(5, 196, 230), 2));

        submit.setBackground(new java.awt.Color(215, 215, 215));
        submit.setText("Submit");

        submit1.setBackground(new java.awt.Color(215, 215, 215));
        submit1.setText("Submit");
        submit1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submit1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(76, 76, 76)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(radio1)
                                        .addGap(18, 18, 18)
                                        .addComponent(radio2))
                                    .addComponent(back))
                                .addGap(32, 32, 32)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(radio3)
                                    .addComponent(submit1))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(43, 43, 43)
                                        .addComponent(radio4)
                                        .addGap(35, 35, 35)
                                        .addComponent(radio5))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGap(181, 181, 181)
                                        .addComponent(next)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(optionLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 972, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(imagePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(74, 74, 74)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(f41d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 67, Short.MAX_VALUE)
                                    .addComponent(f36d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(f31d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(f26d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(f21d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(f16d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(f11d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(f1d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(f6d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(f46d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(10, 10, 10)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(f2d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(f7d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(f12d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 66, Short.MAX_VALUE)
                                    .addComponent(f17d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(f22d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(f27d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(f32d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(f37d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(f42d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(f47d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(92, 92, 92)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(f4d, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(f9d, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(f14d, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(f19d, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(f24d, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(f29d, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(f34d, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(f39d, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(f48d, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(f49d, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addComponent(f38d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 71, Short.MAX_VALUE)
                                                    .addComponent(f33d, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(f28d, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(f23d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(f18d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(f13d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(f8d, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(f3d, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(f43d, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addGap(11, 11, 11)
                                                .addComponent(f44d, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(f25d, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(f10d, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(f5d, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(f15d, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(f20d, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(f30d, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(f40d, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(f45d, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                            .addComponent(f35d, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(103, 103, 103))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(f50d, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(f61d, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(10, 10, 10))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(f56d, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(f51d, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(f57d, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(f62d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(f52d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(f63d, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(f53d, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(f58d, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(f54d, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(f59d, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(f55d, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(f60d, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap())))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(allError)
                            .addComponent(heading, javax.swing.GroupLayout.PREFERRED_SIZE, 1015, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(submit)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(heading)
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(f5d)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(f10d)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(f14d)
                            .addComponent(f15d))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(f19d)
                            .addComponent(f20d))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(f24d)
                            .addComponent(f25d))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(f29d)
                            .addComponent(f30d))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(f34d)
                            .addComponent(f35d))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(f39d)
                            .addComponent(f40d))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(f44d)
                            .addComponent(f45d)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(f1d)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(f6d)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(f11d)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(f16d)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(f21d)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(f26d)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(f31d)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(f36d)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(f41d))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(f2d)
                            .addComponent(f3d)
                            .addComponent(f4d))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(f7d)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(f12d)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(f17d)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(f22d)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(f27d)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(f32d)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(f37d))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(f8d)
                                    .addComponent(f9d))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(f13d)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(f18d)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(f23d)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(f28d)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(f33d)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(f38d)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(f43d)
                                    .addComponent(f42d))))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(f46d)
                            .addComponent(f47d)
                            .addComponent(f48d)
                            .addComponent(f49d)
                            .addComponent(f50d))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(f51d)
                            .addComponent(f52d)
                            .addComponent(f53d)
                            .addComponent(f54d)
                            .addComponent(f55d))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(f56d)
                            .addComponent(f57d)
                            .addComponent(f58d)
                            .addComponent(f59d)
                            .addComponent(f60d))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(f61d)
                            .addComponent(f62d)
                            .addComponent(f63d))
                        .addGap(216, 216, 216)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(radio1)
                            .addComponent(radio2)
                            .addComponent(radio3)
                            .addComponent(radio4)
                            .addComponent(radio5))
                        .addGap(10, 10, 10)
                        .addComponent(allError)
                        .addGap(42, 42, 42)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(back)
                            .addComponent(next)
                            .addComponent(submit1))
                        .addContainerGap(30, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(imagePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(47, 47, 47)
                        .addComponent(optionLabel)
                        .addGap(137, 137, 137))))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(submit)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void radio3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radio3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_radio3ActionPerformed

    private void nextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextActionPerformed
        // TODO add your handling code here:
        if (i  < 62){
            allError.setVisible(false);
            int j = ++i;
            heading.setText(headings[j]);
            desc.setText(description[j]);
            assignBtns(j);
            optionLabel.setText(choosedOptions.get("F"+j+"D"));
            if(checkSelected()){
                record.put("F"+j+"D", getSelected());
                btns.setBackground(gray);
                choosedOptions.put("F"+(j-1)+"D", getSelectedString());
                radioGroup.clearSelection();
            }
            btns.setBorder(BorderFactory.createLineBorder(lightGray, 1));
            checkAll();
            assignBtns(j+1);
            btns.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));    
            try {
                setImage();
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, ex);
            }
        }        
    }//GEN-LAST:event_nextActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        // TODO add your handling code here:
        if (i > 0){
            allError.setVisible(false);
            int j;
            if(checkSelected()){
                j = i + 1 ;
                assignBtns(j);
                btns.setBackground(gray);
                record.put("F"+j+"L", getSelected());
                choosedOptions.put("F"+(j-1)+"D", getSelectedString());
                radioGroup.clearSelection();
            }
            j = --i;
            heading.setText(headings[j]);
            desc.setText(description[j]);
            optionLabel.setText(choosedOptions.get("F"+j+"D"));
            checkAll();
            assignBtns(j+1);
            btns.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));  
            try {
                setImage();
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, ex);
            }
            assignBtns(j+2);
            btns.setBorder(BorderFactory.createLineBorder(lightGray, 1));
            
        }
    }//GEN-LAST:event_backActionPerformed

    private void submit1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submit1ActionPerformed
        // TODO add your handling code here:
        if(checkSelected()){
            assignBtns(i+1);
            record.put("F"+(i+1)+"D", getSelected());
            btns.setBackground(gray);
            choosedOptions.put("F"+i+"D", getSelectedString());
            optionLabel.setText(choosedOptions.get("F"+i+"D"));
        }
        if(record.containsValue(0)){
            allError.setVisible(true);
        }else{
            allError.setVisible(false);
            Result r = new Result(id, name, designation, record, 63);
            r.setVisible(true);
            this.dispose();
        }    
    }//GEN-LAST:event_submit1ActionPerformed
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DFMAEvaluationPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DFMAEvaluationPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DFMAEvaluationPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DFMAEvaluationPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new DFMAEvaluationPage().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel allError;
    private javax.swing.JButton back;
    private javax.swing.JTextArea desc;
    private javax.swing.JButton f10d;
    private javax.swing.JButton f11d;
    private javax.swing.JButton f12d;
    private javax.swing.JButton f13d;
    private javax.swing.JButton f14d;
    private javax.swing.JButton f15d;
    private javax.swing.JButton f16d;
    private javax.swing.JButton f17d;
    private javax.swing.JButton f18d;
    private javax.swing.JButton f19d;
    protected javax.swing.JButton f1d;
    private javax.swing.JButton f20d;
    private javax.swing.JButton f21d;
    private javax.swing.JButton f22d;
    private javax.swing.JButton f23d;
    private javax.swing.JButton f24d;
    private javax.swing.JButton f25d;
    private javax.swing.JButton f26d;
    private javax.swing.JButton f27d;
    private javax.swing.JButton f28d;
    private javax.swing.JButton f29d;
    private javax.swing.JButton f2d;
    private javax.swing.JButton f30d;
    private javax.swing.JButton f31d;
    private javax.swing.JButton f32d;
    private javax.swing.JButton f33d;
    private javax.swing.JButton f34d;
    private javax.swing.JButton f35d;
    private javax.swing.JButton f36d;
    private javax.swing.JButton f37d;
    private javax.swing.JButton f38d;
    private javax.swing.JButton f39d;
    private javax.swing.JButton f3d;
    private javax.swing.JButton f40d;
    private javax.swing.JButton f41d;
    private javax.swing.JButton f42d;
    private javax.swing.JButton f43d;
    private javax.swing.JButton f44d;
    private javax.swing.JButton f45d;
    private javax.swing.JButton f46d;
    private javax.swing.JButton f47d;
    private javax.swing.JButton f48d;
    private javax.swing.JButton f49d;
    private javax.swing.JButton f4d;
    private javax.swing.JButton f50d;
    private javax.swing.JButton f51d;
    private javax.swing.JButton f52d;
    private javax.swing.JButton f53d;
    private javax.swing.JButton f54d;
    private javax.swing.JButton f55d;
    private javax.swing.JButton f56d;
    private javax.swing.JButton f57d;
    private javax.swing.JButton f58d;
    private javax.swing.JButton f59d;
    private javax.swing.JButton f5d;
    private javax.swing.JButton f60d;
    private javax.swing.JButton f61d;
    private javax.swing.JButton f62d;
    private javax.swing.JButton f63d;
    private javax.swing.JButton f6d;
    private javax.swing.JButton f7d;
    private javax.swing.JButton f8d;
    private javax.swing.JButton f9d;
    private javax.swing.JLabel heading;
    private javax.swing.JPanel imagePanel;
    private javax.swing.JLabel imgLabel;
    private javax.swing.JLabel imgLabel2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton next;
    private javax.swing.JLabel optionLabel;
    private javax.swing.JRadioButton radio1;
    private javax.swing.JRadioButton radio2;
    private javax.swing.JRadioButton radio3;
    private javax.swing.JRadioButton radio4;
    private javax.swing.JRadioButton radio5;
    private javax.swing.ButtonGroup radioGroup;
    private javax.swing.JButton submit;
    private javax.swing.JButton submit1;
    // End of variables declaration//GEN-END:variables
}
