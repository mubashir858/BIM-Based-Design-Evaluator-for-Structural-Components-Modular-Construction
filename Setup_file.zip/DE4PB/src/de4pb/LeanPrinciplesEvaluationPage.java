
package de4pb;


import java.awt.Color;
import java.awt.Image;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.SwingConstants;

public final class LeanPrinciplesEvaluationPage extends javax.swing.JFrame {

    String[] headings = new String[29];
    String[] description = new String[30];
    HashMap<String, Integer> record = new HashMap<>();
    HashMap<String, String> choosedOptions = new HashMap<>();
    JButton btns;
    String imagePath = ""
            + "assets/lean principle/L1.png";
    static int i = 0;
    Color gray = new Color(166, 166, 166);
    Color lightGray = new Color(230, 230, 230);
    
    String id, name, designation;
    
    public LeanPrinciplesEvaluationPage(){
        initComponents();
    }
    
    public LeanPrinciplesEvaluationPage(String id, String name, String designation) throws IOException {
        initComponents();
        this.id = id;
        this.name = name;
        this.designation = designation;
//        try{
            headingsRead();
            descRead();
//        }catch(Exception e){
//            JOptionPane.showMessageDialog(this, e);
//        }
        desc.setLineWrap(true);
        allError.setVisible(false);
        desc.setText(description[0]);
        heading.setText(headings[0]);
        setImage();
        btns = f1d;
        btns.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));    
        initRecord();
        optionLabel.setHorizontalAlignment(SwingConstants.CENTER);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
    }
    
    public void headingsRead() throws FileNotFoundException, IOException{
        File hfile = new File("lean_Headings.txt");
        BufferedReader hbr = new BufferedReader(new FileReader(hfile));
        int count = 0;
        String st;
        while((st = hbr.readLine()) != null){
            headings[count++] = st;
        }        
    }
    
    public void descRead() throws FileNotFoundException, IOException {
        File file = new File("lean.txt");
        BufferedReader br = new BufferedReader(new FileReader(file));
        String st;
        int count=0;
        while ( (st = br.readLine()) != null){
            if(count == 29){
                break;
            }
            String s = br.readLine();
            int buff = Integer.parseInt(s);
            String bigStr = "";
            for (int j=0; j<buff; j++){
                bigStr += br.readLine()+"\n";
            }
            description[count] = bigStr;
            count++;
        }
    }
    
    public void assignBtns(int pos){
        int a = pos;
        switch (a){
            case 1:
                btns = f1d;
                imagePath = "assets/lean principle/L1.png";
                break;
            case 2:
                btns = f2d;
                imagePath = "assets/lean principle/L2.png";
                break;
            case 3:
                btns = f3d;
                imagePath = "assets/lean principle/L3.jpg";
                break;
            case 4:
                btns = f4d;
                imagePath = "assets/lean principle/L4.png";
                break;
            case 5:
                btns = f5d;
                imagePath = "assets/lean principle/L5.png";
                break;
            case 6:
                btns = f6d;
                imagePath = "assets/lean principle/L6.png";
                break;
            case 7:
                btns = f7d;
                imagePath = "assets/lean principle/L7.jpg";
                break;
            case 8:
                btns = f8d;
                imagePath = "assets/lean principle/L8.jpg";
                break;
            case 9:
                btns = f9d;
                imagePath = "assets/lean principle/L9.jpg";
                break;
            case 10:
                btns = f10d;
                imagePath = "assets/lean principle/L10.png";
                break;
            case 11:
                btns = f11d;
                imagePath = "assets/lean principle/L11.jpg";
                break;
            case 12:
                btns = f12d;
                imagePath = "assets/lean principle/L12.jpg";
                break;
            case 13:
                btns = f13d;
                imagePath = "assets/lean principle/L13.jpg";
                break;
            case 14:
                btns = f14d;
                imagePath = "assets/lean principle/L14.jpg";
                break;
            case 15:
                btns = f15d;
                imagePath = "assets/lean principle/L15.jpg";
                break;
            case 16:
                btns = f16d;
                imagePath = "assets/lean principle/L16.png";
                break;
            case 17:
                btns = f17d;
                imagePath = "assets/lean principle/L17.jpg";
                break;
            case 18:
                btns = f18d;
                imagePath = "assets/lean principle/L18.png";
                break;
            case 19:
                btns = f19d;
                imagePath = "assets/lean principle/L19.jpg";
                break;
            case 20:
                btns = f20d;
                imagePath = "assets/lean principle/L20.png";
                break;
            case 21:
                btns = f21d;
                imagePath = "assets/lean principle/L21.png";
                break;
            case 22:
                btns = f22d;
                imagePath = "assets/lean principle/L22.png";
                break;
            case 23:
                btns = f23d;
                imagePath = "assets/lean principle/L23.jpg";
                break;
            case 24:
                btns = f24d;
                imagePath = "assets/lean principle/L24.jpg";
                break;
            case 25:
                btns = f25d;
                imagePath = "assets/lean principle/L25.jpg";
                break;
            case 26:
                btns = f26d;
                imagePath = "assets/lean principle/L26.jpg";
                break;
            case 27:
                btns = f27d;
                imagePath = "assets/lean principle/L27.jpg";
                break;
            case 28:
                btns = f28d;
                imagePath = "assets/lean principle/L28.jpg";
                break;
            case 29:
                btns = f29d;
                imagePath = "assets/lean principle/L29.png";
                break;
        }
    }
    
    public boolean checkSelected(){
        boolean isSelected = false;
        if (radio1.isSelected()){
            isSelected = true;
        }
        else if (radio2.isSelected()){
            isSelected = true;
        }
        else if (radio3.isSelected()){
            isSelected = true;
        }
        else if (radio4.isSelected()){
            isSelected = true;
        }
        else if (radio5.isSelected()){
            isSelected = true;
        }
        return isSelected;
    }
   
    public int getSelected(){
        int res = 0;
        if (radio1.isSelected()){
            res = 1;
        }
        else if (radio2.isSelected()){
            res = 2;
        }
        else if (radio3.isSelected()){
            res = 3;
        }
        else if (radio4.isSelected()){
            res = 4;
        }
        else if (radio5.isSelected()){
            res = 5;
        }
        return res;
    }
    
    public String getSelectedString(){
        String res = "";
        if (radio1.isSelected()){
            res = "Very Unsatisfied";
        }
        else if (radio2.isSelected()){
            res = "Unsatisfied";
        }
        else if (radio3.isSelected()){
            res = "Neutral";
        }
        else if (radio4.isSelected()){
            res = "Satisfied";
        }
        else if (radio5.isSelected()){
            res = "Very Satisfied";
        }
        return res;
    }
    
    public void setSelectedBtn(){
        JRadioButton jrbtn = null;
        if(radio1.isSelected()){
            jrbtn = radio1;
        }else if(radio2.isSelected()){
            jrbtn = radio2;
        }else if(radio3.isSelected()){
            jrbtn = radio3;
        }else if(radio4.isSelected()){
            jrbtn = radio4;
        }else if(radio5.isSelected()){
            jrbtn = radio5;
        }
        
        jrbtn.setSelected(true);
    }
    
    public void setOption(){
        int opt = record.get("F"+i+"L");
        String txt = "";
        switch (opt) {
            case 0:
                txt = "";
                break;
            case 1:
                txt = "Very Unsatisfied";
                break;
            case 2:
                txt = "Unsatisfied";
                break;
            case 3:
                txt = "Neutral";
                break;
            case 4:
                txt = "Satisfied";
                break;
            case 5:
                txt = "Very Satisfied";
                break;
            default:
                break;
        }
        optionLabel.setText(txt);
    }
    
    public ImageIcon image(String path){
        ImageIcon icon = new ImageIcon(path);
        Image image = icon.getImage(); // transform it 
        Image newimg = image.getScaledInstance(350, 200,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
        icon = new ImageIcon(newimg);
        return icon;
    }
    
    public void setImage() throws IOException{
        imgLabel.setIcon(image(imagePath));
        String path = "assets/lean principle/";
        
        if(i==9)
            path += "L10.jpg";
        if(i==16)
            path += "L17.png";        
    
        imgLabel2.setIcon(image(path));
    }

    public void initRecord(){
        record.put("F1L", 0);
        record.put("F2L", 0);
        record.put("F3L", 0);
        record.put("F4L", 0);
        record.put("F5L", 0);
        record.put("F6L", 0);
        record.put("F7L", 0);
        record.put("F8L", 0);
        record.put("F9L", 0);
        record.put("F10L", 0);
        record.put("F11L", 0);
        record.put("F12L", 0);
        record.put("F13L", 0);
        record.put("F14L", 0);
        record.put("F15L", 0);
        record.put("F16L", 0);
        record.put("F17L", 0);
        record.put("F18L", 0);
        record.put("F19L", 0);
        record.put("F20L", 0);
        record.put("F21L", 0);
        record.put("F22L", 0);
        record.put("F23L", 0);
        record.put("F24L", 0);
        record.put("F25L", 0);
        record.put("F26L", 0);
        record.put("F27L", 0);
        record.put("F28L", 0);
        record.put("F29L", 0);
    }
    
    public void initChoosedOptions(){
        choosedOptions.put("F1L", "");
        choosedOptions.put("F2L", "");
        choosedOptions.put("F3L", "");
        choosedOptions.put("F4L", "");
        choosedOptions.put("F5L", "");
        choosedOptions.put("F6L", "");
        choosedOptions.put("F7L", "");
        choosedOptions.put("F8L", "");
        choosedOptions.put("F9L", "");
        choosedOptions.put("F10L", "");
        choosedOptions.put("F11L", "");
        choosedOptions.put("F12L", "");
        choosedOptions.put("F13L", "");
        choosedOptions.put("F14L", "");
        choosedOptions.put("F15L", "");
        choosedOptions.put("F16L", "");
        choosedOptions.put("F17L", "");
        choosedOptions.put("F18L", "");
        choosedOptions.put("F19L", "");
        choosedOptions.put("F20L", "");
        choosedOptions.put("F21L", "");
        choosedOptions.put("F22L", "");
        choosedOptions.put("F23L", "");
        choosedOptions.put("F24L", "");
        choosedOptions.put("F25L", "");
        choosedOptions.put("F26L", "");
        choosedOptions.put("F27L", "");
        choosedOptions.put("F28L", "");
        choosedOptions.put("F29L", "");
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        f1d = new javax.swing.JButton();
        f2d = new javax.swing.JButton();
        f3d = new javax.swing.JButton();
        f4d = new javax.swing.JButton();
        f5d = new javax.swing.JButton();
        f6d = new javax.swing.JButton();
        f7d = new javax.swing.JButton();
        f8d = new javax.swing.JButton();
        f9d = new javax.swing.JButton();
        f10d = new javax.swing.JButton();
        f17d = new javax.swing.JButton();
        f18d = new javax.swing.JButton();
        f19d = new javax.swing.JButton();
        f20d = new javax.swing.JButton();
        f11d = new javax.swing.JButton();
        f12d = new javax.swing.JButton();
        f13d = new javax.swing.JButton();
        f14d = new javax.swing.JButton();
        f15d = new javax.swing.JButton();
        f16d = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        desc = new javax.swing.JTextArea();
        f27d = new javax.swing.JButton();
        heading = new javax.swing.JLabel();
        f28d = new javax.swing.JButton();
        imagePanel = new javax.swing.JPanel();
        imgLabel = new javax.swing.JLabel();
        imgLabel2 = new javax.swing.JLabel();
        f29d = new javax.swing.JButton();
        f21d = new javax.swing.JButton();
        f22d = new javax.swing.JButton();
        f23d = new javax.swing.JButton();
        f24d = new javax.swing.JButton();
        f25d = new javax.swing.JButton();
        f26d = new javax.swing.JButton();
        radio1 = new javax.swing.JRadioButton();
        radio2 = new javax.swing.JRadioButton();
        radio3 = new javax.swing.JRadioButton();
        radio4 = new javax.swing.JRadioButton();
        radio5 = new javax.swing.JRadioButton();
        back = new javax.swing.JButton();
        allError = new javax.swing.JLabel();
        submit = new javax.swing.JButton();
        next = new javax.swing.JButton();
        optionLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        f1d.setBackground(new java.awt.Color(230, 230, 230));
        f1d.setText("F1L");
        f1d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f2d.setBackground(new java.awt.Color(230, 230, 230));
        f2d.setText("F2L");
        f2d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f3d.setBackground(new java.awt.Color(230, 230, 230));
        f3d.setText("F3L");
        f3d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f4d.setBackground(new java.awt.Color(230, 230, 230));
        f4d.setText("F4L");
        f4d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f5d.setBackground(new java.awt.Color(230, 230, 230));
        f5d.setText("F5L");
        f5d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f6d.setBackground(new java.awt.Color(230, 230, 230));
        f6d.setText("F6L");
        f6d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f7d.setBackground(new java.awt.Color(230, 230, 230));
        f7d.setText("F7L");
        f7d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f8d.setBackground(new java.awt.Color(230, 230, 230));
        f8d.setText("F8L");
        f8d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f9d.setBackground(new java.awt.Color(230, 230, 230));
        f9d.setText("F9L");
        f9d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f10d.setBackground(new java.awt.Color(230, 230, 230));
        f10d.setText("F10L");
        f10d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f17d.setBackground(new java.awt.Color(230, 230, 230));
        f17d.setText("F17L");
        f17d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f18d.setBackground(new java.awt.Color(230, 230, 230));
        f18d.setText("F18L");
        f18d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f19d.setBackground(new java.awt.Color(230, 230, 230));
        f19d.setText("F19L");
        f19d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f20d.setBackground(new java.awt.Color(230, 230, 230));
        f20d.setText("F20L");
        f20d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f11d.setBackground(new java.awt.Color(230, 230, 230));
        f11d.setText("F11L");
        f11d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f12d.setBackground(new java.awt.Color(230, 230, 230));
        f12d.setText("F12L");
        f12d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f13d.setBackground(new java.awt.Color(230, 230, 230));
        f13d.setText("F13L");
        f13d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f14d.setBackground(new java.awt.Color(230, 230, 230));
        f14d.setText("F14L");
        f14d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f15d.setBackground(new java.awt.Color(230, 230, 230));
        f15d.setText("F15L");
        f15d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f16d.setBackground(new java.awt.Color(230, 230, 230));
        f16d.setText("F16L");
        f16d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        jPanel1.setBackground(new java.awt.Color(191, 191, 191));

        jLabel1.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel1.setText("Design Evaluation using Lean Principles ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(473, 473, 473))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jScrollPane1.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        desc.setEditable(false);
        desc.setBackground(new java.awt.Color(240, 240, 240));
        desc.setColumns(20);
        desc.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        desc.setRows(5);
        jScrollPane1.setViewportView(desc);

        f27d.setBackground(new java.awt.Color(230, 230, 230));
        f27d.setText("F27L");
        f27d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        heading.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        heading.setText("heading");

        f28d.setBackground(new java.awt.Color(230, 230, 230));
        f28d.setText("F28L");
        f28d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        javax.swing.GroupLayout imagePanelLayout = new javax.swing.GroupLayout(imagePanel);
        imagePanel.setLayout(imagePanelLayout);
        imagePanelLayout.setHorizontalGroup(
            imagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(imagePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(imgLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 498, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(imgLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 444, Short.MAX_VALUE)
                .addContainerGap())
        );
        imagePanelLayout.setVerticalGroup(
            imagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, imagePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(imagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(imgLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 207, Short.MAX_VALUE)
                    .addComponent(imgLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        f29d.setBackground(new java.awt.Color(230, 230, 230));
        f29d.setText("F29L");
        f29d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f21d.setBackground(new java.awt.Color(230, 230, 230));
        f21d.setText("F21L");
        f21d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f22d.setBackground(new java.awt.Color(230, 230, 230));
        f22d.setText("F22L");
        f22d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f23d.setBackground(new java.awt.Color(230, 230, 230));
        f23d.setText("F23L");
        f23d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f24d.setBackground(new java.awt.Color(230, 230, 230));
        f24d.setText("F24L");
        f24d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f25d.setBackground(new java.awt.Color(230, 230, 230));
        f25d.setText("F25L");
        f25d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        f26d.setBackground(new java.awt.Color(230, 230, 230));
        f26d.setText("F26L");
        f26d.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(230, 230, 230)));

        buttonGroup1.add(radio1);
        radio1.setText("Very Unsatisfied");

        buttonGroup1.add(radio2);
        radio2.setText("Usatisfied");

        buttonGroup1.add(radio3);
        radio3.setText("Neutral");
        radio3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radio3ActionPerformed(evt);
            }
        });

        buttonGroup1.add(radio4);
        radio4.setText("Satisfied");

        buttonGroup1.add(radio5);
        radio5.setText("Very Satisfied");

        back.setBackground(new java.awt.Color(215, 215, 215));
        back.setText("Back");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });

        allError.setForeground(new java.awt.Color(255, 0, 0));
        allError.setText("All questions must be answered!");

        submit.setBackground(new java.awt.Color(215, 215, 215));
        submit.setText("Submit");
        submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitActionPerformed(evt);
            }
        });

        next.setBackground(new java.awt.Color(215, 215, 215));
        next.setText("Next");
        next.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextActionPerformed(evt);
            }
        });

        optionLabel.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        optionLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(5, 196, 230), 2));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(heading, javax.swing.GroupLayout.PREFERRED_SIZE, 1015, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(imagePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(optionLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 972, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(92, 92, 92)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(f21d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(f16d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(f11d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(f6d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(f1d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(f26d, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(f2d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(f7d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(f12d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(f17d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(f22d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(f27d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(f28d, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(f23d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(f18d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(f13d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(f8d, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(f3d, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(f24d, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(f25d, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(f29d, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(f19d, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(f20d, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(f14d, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(f15d, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(f9d, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(f10d, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(f4d, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(f5d, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap(52, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(86, 86, 86)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(radio1)
                                    .addGap(18, 18, 18)
                                    .addComponent(radio2))
                                .addComponent(back))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(36, 36, 36)
                                    .addComponent(radio3)
                                    .addGap(43, 43, 43)
                                    .addComponent(radio4)
                                    .addGap(35, 35, 35)
                                    .addComponent(radio5))
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(21, 21, 21)
                                    .addComponent(submit)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(next))))
                        .addComponent(allError))
                    .addContainerGap(930, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(88, 88, 88)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(f3d)
                                        .addComponent(f4d)
                                        .addComponent(f5d))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(f8d)
                                        .addComponent(f9d)
                                        .addComponent(f10d))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(f13d)
                                        .addComponent(f14d)
                                        .addComponent(f15d))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(f18d)
                                        .addComponent(f19d)
                                        .addComponent(f20d))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(f23d)
                                        .addComponent(f24d)
                                        .addComponent(f25d))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(f28d)
                                        .addComponent(f29d)))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(f2d)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(f7d)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(f12d)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(f17d)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(f22d)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(f27d)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(f1d)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(f6d)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(f11d)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(f16d)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(f21d)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(f26d))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(heading)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(imagePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 93, Short.MAX_VALUE)
                .addComponent(optionLabel)
                .addGap(147, 147, 147))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(631, 631, 631)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(radio1)
                        .addComponent(radio2)
                        .addComponent(radio3)
                        .addComponent(radio4)
                        .addComponent(radio5))
                    .addGap(10, 10, 10)
                    .addComponent(allError)
                    .addGap(42, 42, 42)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(back)
                        .addComponent(submit)
                        .addComponent(next))
                    .addContainerGap(63, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void radio3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radio3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_radio3ActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        // TODO add your handling code here:
        if (i > 0){
            allError.setVisible(false);
            if(checkSelected()){
                assignBtns(i+1);
                record.put("F"+(i+1)+"L", getSelected());
                btns.setBackground(gray);
                choosedOptions.put("F"+i+"L", getSelectedString());
                buttonGroup1.clearSelection();
            }
            int j = --i;
            heading.setText(headings[j]);
            desc.setText(description[j]);
            optionLabel.setText(choosedOptions.get("F"+j+"L"));
            assignBtns(j+1);
            btns.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
            try {
                setImage();
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, ex);
            }
            assignBtns(j+2);
            btns.setBorder(BorderFactory.createLineBorder(lightGray, 1));

        }
    }//GEN-LAST:event_backActionPerformed

    private void nextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextActionPerformed
        // TODO add your handling code here:
        if (i  < 28){
            allError.setVisible(false);
            int j = ++i;
            heading.setText(headings[j]);
            desc.setText(description[j]);
            assignBtns(j);
            optionLabel.setText(choosedOptions.get("F"+j+"L"));
            if(checkSelected()){
                record.put("F"+j+"L", getSelected());
                btns.setBackground(gray);
                choosedOptions.put("F"+(j-1)+"L", getSelectedString());
                buttonGroup1.clearSelection();
            }
            btns.setBorder(BorderFactory.createLineBorder(lightGray, 1));
            assignBtns(j+1);
            btns.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
            try {
                setImage();
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, ex);
            }
        }
    }//GEN-LAST:event_nextActionPerformed

    private void submitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitActionPerformed
        // TODO add your handling code here:
        if(checkSelected()){
            assignBtns(i+1);
            record.put("F"+(i+1)+"L", getSelected());
            btns.setBackground(gray);
            choosedOptions.put("F"+i+"L", getSelectedString());
            optionLabel.setText(choosedOptions.get("F"+i+"L"));
        }
        if(record.containsValue(0)){
            allError.setVisible(true);Result r = new Result(id, name, designation, record, 29);
            r.setVisible(true);
            this.dispose();
            
        }else{
            allError.setVisible(false);
            Result r = new Result(id, name, designation, record, 29);
            r.setVisible(true);
            this.dispose();
        }
    }//GEN-LAST:event_submitActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LeanPrinciplesEvaluationPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LeanPrinciplesEvaluationPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LeanPrinciplesEvaluationPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LeanPrinciplesEvaluationPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new LeanPrinciplesEvaluationPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel allError;
    private javax.swing.JButton back;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JTextArea desc;
    private javax.swing.JButton f10d;
    private javax.swing.JButton f11d;
    private javax.swing.JButton f12d;
    private javax.swing.JButton f13d;
    private javax.swing.JButton f14d;
    private javax.swing.JButton f15d;
    private javax.swing.JButton f16d;
    private javax.swing.JButton f17d;
    private javax.swing.JButton f18d;
    private javax.swing.JButton f19d;
    protected javax.swing.JButton f1d;
    private javax.swing.JButton f20d;
    private javax.swing.JButton f21d;
    private javax.swing.JButton f22d;
    private javax.swing.JButton f23d;
    private javax.swing.JButton f24d;
    private javax.swing.JButton f25d;
    private javax.swing.JButton f26d;
    private javax.swing.JButton f27d;
    private javax.swing.JButton f28d;
    private javax.swing.JButton f29d;
    private javax.swing.JButton f2d;
    private javax.swing.JButton f3d;
    private javax.swing.JButton f4d;
    private javax.swing.JButton f5d;
    private javax.swing.JButton f6d;
    private javax.swing.JButton f7d;
    private javax.swing.JButton f8d;
    private javax.swing.JButton f9d;
    private javax.swing.JLabel heading;
    private javax.swing.JPanel imagePanel;
    private javax.swing.JLabel imgLabel;
    private javax.swing.JLabel imgLabel2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton next;
    private javax.swing.JLabel optionLabel;
    private javax.swing.JRadioButton radio1;
    private javax.swing.JRadioButton radio2;
    private javax.swing.JRadioButton radio3;
    private javax.swing.JRadioButton radio4;
    private javax.swing.JRadioButton radio5;
    private javax.swing.JButton submit;
    // End of variables declaration//GEN-END:variables
}
